#pragma once

#include <defs.h>

namespace EF {
    double getDeficit(class Parameter * param);
    double getMaxValue(class Parameter * param);
}
