#include "exhaustivesearcher.h"

#include "element.h"
#include "network.h"
#include "criteria.h"
#include "operation.h"
#include "path.h"
#include "link.h"
#include "port.h"
//#include "parameter.h"
#include "request.h"
#include "routing/bsearcher.h"

#include <algorithm>
#include <iostream>

using std::vector;

#include <stdio.h>

//
#include "leafnode.h"
#include "migration.h"
#include "transmission.h"
#include "prototype.h"
//

typedef std::map<Parameter *, ParameterValue *> Parameters;
typedef std::set<Request *> Requests;

ExhaustiveSearcher::ExhaustiveSearcher(Network * n, const Resources & res, const TenantsElements & tens,
                                       Elements & p, Element * t, const Elements & assignedElements,
                                       const bool & twoStage, int d, int ma)
:
    //
    network(n),
    resources(res),
    tenantsElements(tens),
    assignedElements(assignedElements),
    twoStage(twoStage),
    pool(p),
    //
    target(t),
    maxAttempts(ma),
    attempt(0),
    depth(d)
{
    // std::cout << std::endl << std::endl << "ExhaustiveSearcher" << std::endl << std::endl;
    Elements cand = Operation::filter(pool, target, Criteria::isExhaustiveCandidate);
    if ( cand.size() < depth )
        depth = cand.size();

    candidates = vector<Element *>(cand.begin(), cand.end());
    indices = new int[depth + 1];
    for ( int i = 0; i < depth; i++ )
        indices[i] = i;
    indices[depth] = candidates.size();
    // printf("Created exhaustive search environment to assign element %p, %d possible candidates\n", t, candidates.size());
}

ExhaustiveSearcher::~ExhaustiveSearcher() {
    printf("Exhaustive search decomposing, attempted %d of %d attempts,", attempt, maxAttempts);
    if ( isExhausted() )
        printf(" is exhausted\n");
    else
        printf(" not exhausted\n");

    delete indices;
}

bool ExhaustiveSearcher::isValid() const {
    if ( !target ) return false;
    if ( !target->isVirtual() ) return false;
    if ( !target->isNode() ) return false;
    return true;
}

bool ExhaustiveSearcher::isExhausted() const {
    return indices[depth - 1] == indices[depth];
}

bool ExhaustiveSearcher::search() {
    if ( !isValid() )
       return false;

    while( !isExhausted() ) {
        attempt++;
        if ( attempt > maxAttempts )
            return false;
        if ( makeAttempt() )
            return true;
    }

    return false;
}

bool ExhaustiveSearcher::makeAttempt() {
    if ( isExhausted() )
        return false;

    Elements cortege = getNextCortege();
    
    Assignments cache = getAssignmentsCache(cortege);
    Elements assignmentPack = getAssignmentPack(cache);
    //Save old pathes

    std::map<Link *, Path> oldPathes;

    for(Elements::iterator i = assignmentPack.begin(); i != assignmentPack.end(); i++ ) {
        Element *assignment = *i;
        Elements edges = assignment->adjacentEdges();
        for (Elements::iterator e = edges.begin(); e != edges.end(); e++) {
            Element *edge = *e;
            Link *tunnel = edge->toLink();
            if (!tunnel->isAssigned())
                continue;

            Path oldPath = tunnel->getRoute();
            oldPathes[tunnel] = oldPath;
        }
    }
    //

    if (!checkAssignmentAvailability(target, cortege))
        return false;

    Operation::forEach(assignmentPack, Operation::unassign);
//    PrototypeAlgorithm::linkChange = true;


    assignmentPack.insert(target);
    if ( performGreedyAssignment(assignmentPack, cortege) ) {

        //Work with channel
        //assignmentPack = oldFixed + currFixed + oldMoved + currMoved + target
        //oldFixed - restore channel
        //currFixed - do nothing
        //oldMoved - find pathes in UpdatePathes
        //currMoved - do nothing

        Elements oldElements = Operation::minus(assignmentPack, assignedElements);
        oldElements.erase(target);

        Elements needUpdatePathes;

        if (twoStage) {
            needUpdatePathes = oldElements;
        } else {
            needUpdatePathes = assignmentPack;
        }


        if ( updatePathes(needUpdatePathes) ) {
//            PrototypeAlgorithm::linkChange = true;

            return true;
        }
        //если обновить пути не удалось, следовательно, отказываемся от назначения, которое было
        //предоставлено методом performGreedyAssignment

        // assignmentPack = Operation::join(oldElements, assignedElements);
        // assignmentPack.insert(target);

        Operation::forEach(assignmentPack, Operation::unassign);
    }
    
    //Restore old location and old Pathes
    for(Assignments::iterator i = cache.begin(); i != cache.end(); i++ ) 
        i->second->assign(i->first);

    for (std::map<Link *, Path>::iterator i = oldPathes.begin(); i != oldPathes.end(); i++) {
        Link * link = i->first;
        Path route = i->second;
        std::vector<Element *> path = route.getPath();
        for (size_t j = 0; j < path.size(); j++) {
            if (path[j]->isLink())
                path[j]->toLink()->assignLink(link);
        }
        link->setRoute(route);
        link->setAssignedFlag(true);
    }
    assignmentPack.erase(target);
    // End of restore

    std::map<std::string, double> m_ph;

    m_ph.insert(std::pair<std::string, double>("RAM", 14)); // граница для ОЗУ
    m_ph.insert(std::pair<std::string, double>("VCPUs",7)); // граница для количества ядер
    m_ph.insert(std::pair<std::string, double>("size", 490)); // граница для количества памяти

    bool heavy_req = false;
// проверяем тяжелый ли текущий элемент
    // std::cout << std::endl << "TARGET " << count++ << std::endl;
    Parameters t_p = target->getParameters();
    Parameters::iterator vpBegin = t_p.begin();
    Parameters::iterator vpEnd = t_p.end();
    for ( Parameters::iterator p= vpBegin; p != vpEnd; p++ ) {
        if (p->second->weight() > m_ph[p->first->getName()]) {
            heavy_req = true;
            break;
        }
    }

// формируем множество легких запросов, которые можно снять, и множество тяжелых, которые нужно перераспределить
    // if (heavy_req) std::cout << "Текущий запрос тяжелый " << heavy_req << std::endl;
    if (heavy_req) {
        Elements light, heavy;
        std::vector<Request *> light_req;
        bool h = false; 
        int aff = -1; // -1 - не определено, 0 - нет политики, 1 - желательная, 2 - обязательная
        int c = 0;

        for (Elements::iterator i = assignmentPack.begin(); i != assignmentPack.end(); i++) {
            h = false;
            //Requests::iterator r_begin = (*i)->request.begin(), r_end = = (*i)->request.end();
            Elements req = (*i)->request->getElements();
            // std::cout << std::endl << std::endl << "REQ" << std:: endl;
            for (Elements::iterator r = req.begin(); r != req.end(); r++) {

                Parameters param = (*r)->getParameters();
                vpBegin = param.begin();
                vpEnd = param.end();

                for (Parameters::iterator p = vpBegin; p != vpEnd; p++) {
                    // std::cout << p->first->getName()<< ' ' << p->second->weight() << std::endl;  
                    if (p->second->weight() > m_ph[p->first->getName()] or (*r)->checkObligatoryAff()) {
                       h = true;
                       break;
                    }
                }
            }
            // std::cout << h << std::endl;
            if (!h) {
                // std::cout << "light " << (*i)->request->getName() << std::endl; 
                light_req.push_back((*i)->request);
                for (Elements::iterator r = req.begin(); r != req.end(); r++) {
                    light.insert(*r);
                }
                c++;
            } else {
                heavy.insert(*i);
                // std::cout << "Запрос добавлен в тяжелые" << std::endl;
            }
        }

        if (!light.empty()) {

            Elements ph;
            for (Elements::iterator i = pool.begin(); i != pool.end(); i++) {
                for (Elements::iterator j = light.begin(); j != light.end(); j++) {
                    if ((*i)->getAssignments().find(*j) != (*i)->getAssignments().end()) {
                        ph.insert(*i);
                        // std::cout << "Элемент из пула добавлен" << std::endl;
                    }
                }
                for (Elements::iterator j = heavy.begin(); j != heavy.end(); j++) {
                    if ((*i)->getAssignments().find(*j) != (*i)->getAssignments().end()) {
                        ph.insert(*i);
                        // std::cout << "Элемент из пула добавлен" << std::endl;
                    }
                }
            }

            heavy.insert(target);
            cache = getAssignmentsCache(ph);
            Elements assignmentPack = heavy;

            Elements oldAssign = getAssignmentPack(cache);
            oldPathes.clear();

            for(Elements::iterator i = oldAssign.begin(); i != oldAssign.end(); i++ ) {
                Element *assignment = *i;
                Elements edges = assignment->adjacentEdges();
                for (Elements::iterator e = edges.begin(); e != edges.end(); e++) {
                    Element *edge = *e;
                    Link *tunnel = edge->toLink();
                    if (!tunnel->isAssigned())
                        continue;

                    Path oldPath = tunnel->getRoute();
                    oldPathes[tunnel] = oldPath;
                }
            }

            Operation::forEach(light, Operation::unassign);
            Operation::forEach(heavy, Operation::unassign);

            if ( performGreedyAssignment(heavy, cortege) ) {
                Elements oldElements = Operation::minus(assignmentPack, assignedElements);
                oldElements.erase(target);

                Elements needUpdatePathes = oldElements;

                if (twoStage) {
                    needUpdatePathes = oldElements;
                } else {
                    needUpdatePathes = assignmentPack;
                }
                if ( updatePathes(needUpdatePathes) ) {
                    std::cout << "ask" << std::endl;
                    
                    if (ask_meta_to_take_tenant_away(*target, light_req)) { 
                        remove(light, ph); // снимаем запросы
                        std::cout << "Вернули " << c << " легких запросов" << std::endl << std::endl;
                        return true;
                    } 
                }
            }
            Operation::forEach(heavy, Operation::unassign);
        } 
        //Restore old location and old Pathes
        for(Assignments::iterator i = cache.begin(); i != cache.end(); i++ ) 
            i->second->assign(i->first);

        for (std::map<Link *, Path>::iterator i = oldPathes.begin(); i != oldPathes.end(); i++) {
            Link * link = i->first;
            Path route = i->second;
            std::vector<Element *> path = route.getPath();
            for (size_t j = 0; j < path.size(); j++) {
                if (path[j]->isLink())
                    path[j]->toLink()->assignLink(link);
            }
            link->setRoute(route);
            link->setAssignedFlag(true);
        }
    }
    
    return false;
}

bool ExhaustiveSearcher::ask_meta_to_take_tenant_away(Element & cur, std::vector<Request *> & req) {
    for (auto i : req) {
        i->remove(cur.request->getName());
    }
    // std::cout << "request name " << cur.request->getName() << std::endl;
    return true;
}

bool ExhaustiveSearcher::remove(Elements & el, Elements & ph) {
    for (Elements::iterator j = ph.begin(); j != ph.end(); j++) {
        for (Elements::iterator i = el.begin(); i != el.end(); i++) {
            (*j)->removeAssignment(*i);
        }
    }
    return true;
}

Elements ExhaustiveSearcher::getNextCortege() {
    Elements result;
    for ( int i = 0; i < depth; i++ ) {
        result.insert(candidates[indices[i]]);
    }
    advanceCursors();
    return result;
}

void ExhaustiveSearcher::advanceCursors() {
    int border = 0;
    for ( int i = depth - 1; i >= 0; i-- ) {
        if ( indices[i] != indices[i+1] - 1) {
            border = i;
            break;
        }
    }

    indices[border]++;
    for (int i = border + 1; i < depth; i++) {
        indices[i] = indices[i-1] + 1;
    }
}

ExhaustiveSearcher::Assignments ExhaustiveSearcher::getAssignmentsCache(Elements & resources) {
    Assignments result;
    for (Elements::iterator i = resources.begin(); i != resources.end(); i++) {
        Element * resource = *i;
        Elements assignments = resource->getAssignments();
        for(Elements::iterator a = assignments.begin(); a != assignments.end(); a++ ) {
            Element * assignment = *a;
	    //check the elements for which migration is not allowed
	    if ( assignment->isComputer() || assignment->isStore() ) {
		    LeafNode * node = (LeafNode *)assignment;
		    if ( node->getMigration() == 0 )
			    continue;
	    }
	    //
            result[assignment] = resource;
        }
    }
    return result;
}

Elements ExhaustiveSearcher::getAssignmentPack(ExhaustiveSearcher::Assignments & assignments) {
    Elements result;
    for (Assignments::iterator i = assignments.begin(); i != assignments.end(); i++) {
        result.insert(i->first);
    }
    return result;
}

bool ExhaustiveSearcher::performGreedyAssignment(Elements & t, Elements & p) {
    std::vector<Element *> targets(t.begin(), t.end());
    std::vector<Element *> physical(p.begin(), p.end());

//    for (std::vector<Element *>::iterator i = targets.begin(); i != targets.end(); i++) {
//        Element * elem = (*i);
//        elem->value = PrototypeAlgorithm::virtualElementValue(elem);
//    }
//
//
//    for (size_t i = 0; i < physical.size(); i++) {
//        Element * elem = physical[i];
//        elem->value = PrototypeAlgorithm::physicalElementValue(physical[i], network);
//    }
////    PrototypeAlgorithm::linkChange = false;
//
//
//    std::sort(targets.begin(), targets.end(), PrototypeAlgorithm::descendingVirt);
//    std::sort(physical.begin(), physical.end(), PrototypeAlgorithm::ascendingPhys);

     std::sort(targets.begin(), targets.end(), Criteria::elementWeightDescending);
     std::sort(physical.begin(), physical.end(), Criteria::elementWeightAscending);


    for(std::vector<Element *>::iterator i = targets.begin(); i != targets.end(); i++) {
        Element * element = *i;
        bool result = false;
        for (std::vector<Element *>::iterator j = physical.begin(); j != physical.end(); j++) {
            Element * assignee = *j;
            result = assignee->assign(element);
            if ( result ) {
                break;
            }
        }

        if ( !result ) {
            Operation::forEach(t, Operation::unassign);
            return false;
        }

//        for (size_t k = 0; k < physical.size(); k++) {
//            Element * elem = physical[k];
//            elem->value = PrototypeAlgorithm::physicalElementValue(physical[k], network);
//        }
////        PrototypeAlgorithm::linkChange = false;
//
//        std::sort(physical.begin(), physical.end(), PrototypeAlgorithm::ascendingPhys);
        std::sort(physical.begin(), physical.end(), Criteria::elementWeightAscending);
    }

    return true;
}

bool ExhaustiveSearcher::updatePathes(Elements & assignments) {
    Elements edges;
    std::vector<Element *> tunnels;

    for(Elements::iterator i = assignments.begin(); i != assignments.end(); i++ ) {
        Element *assignment = *i;
        edges = Operation::join(edges, assignment->adjacentEdges());
        //edges.insert(assignment->adjacentEdges().begin(), assignment->adjacentEdges().end());
    }

    tunnels.insert(tunnels.end(), edges.begin(), edges.end());
    std::sort(tunnels.begin(), tunnels.end(), Criteria::elementWeightDescending);
    for(size_t e = 0; e < tunnels.size(); e ++) {
        Element * edge = tunnels[e];
        Link * tunnel = edge->toLink();
        if (tunnel->isAssigned())
            continue;
        Element * start = tunnel->getFirst()->getParentNode()->getAssignee();
        Element * end = tunnel->getSecond()->getParentNode()->getAssignee();
        BSearcher searcher(start, end, tunnel);
        if ( start == end ) {
            Path emptyPath = Path(end, start);
            tunnel->setRoute(emptyPath);
            tunnel->setAssignedFlag(true);
            continue;
        }
        if ( !searcher.isValid() ) {
            continue;
        }
        if ( !searcher.search() ) {
            // std::cout << "Path update failed" << std::endl;
            return false;
        }
        Path route = searcher.getPath();
        tunnel->setRoute(route);
        tunnel->setAssignedFlag(true);
    }

    return true;
}

//
ExhaustiveSearcher::Assignments ExhaustiveSearcher::getNewAssignment(Elements & assignments) {
	Assignments result;
	for (Elements::iterator i = assignments.begin(); i != assignments.end(); i++) {
		Element * resource = (*i)->getAssignee();
		result[(*i)] = resource;
	}
	return result;
}

Transmissions ExhaustiveSearcher::getTransmissions(ExhaustiveSearcher::Assignments & oldAssignment, ExhaustiveSearcher::Assignments & newAssignment) {
	Transmissions result;
	for (Assignments::iterator i = oldAssignment.begin(); i != oldAssignment.end(); i++) {
		if ( i->second != newAssignment[i->first] ) {//if source != destination
			Transmission * transmission = new Transmission (i->first, i->second, newAssignment[i->first]);
			result.push_back( transmission );
		}
	}
	return result;
}


bool ExhaustiveSearcher::checkAssignmentAvailability(Element * target, Elements nodes) {
    if (nodes.empty())
        return false;

    Parameters parameters = (*nodes.begin())->getParameters();
    std::map<std::string, double> availableResources;
    Parameters::iterator first = parameters.begin();
    Parameters::iterator last = parameters.end();

    for (Parameters::iterator param = first; param != last; param++ ) {
        availableResources[param->first->getName()] = 0.0;
    }

    for ( Elements::iterator node = nodes.begin(); node != nodes.end(); node++ ) {
        std::map<std::string, double> nodeParameters = (*node)->getParametersTotal();
        std::map<std::string, double>::iterator firstParam = nodeParameters.begin();
        std::map<std::string, double>::iterator lastParam = nodeParameters.end();
        for ( std::map<std::string, double>::iterator param = firstParam; param != lastParam; param++ ) {
            std::string paramName = param->first;
            double paramValue = param->second;
            availableResources[paramName] += paramValue;
        }
    }

    std::map<std::string, double> targetResources = target->getParametersTotal();

    std::map<std::string, double>::iterator v;
    for ( v = targetResources.begin(); v != targetResources.end(); v++) {
        std::string paramName = v->first;
        double paramValue = v->second;
        if (paramValue > availableResources[paramName]){
            return false;
        }
    }

    return true;
}